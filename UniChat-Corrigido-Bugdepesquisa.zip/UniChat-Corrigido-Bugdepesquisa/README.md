﻿# UniChat

UniChat e uma aplicacao corporativa interna para centralizacao do conhecimento institucional. A consulta acontece somente sobre documentos oficiais cadastrados na base local, com resposta acompanhada de fonte, setor, categoria e versao.

## Como rodar

```bash
npm start
```

Acesse:

```text
http://localhost:3000
```

## Acessos iniciais

Todos usam a senha inicial:

```text
Unichat@2026
```

Usuarios:

```text
admin@unimeduberlandia.coop.br
gestor@unimeduberlandia.coop.br
colaborador@unimeduberlandia.coop.br
```

## Perfis

- Colaborador: acessa o chat e avalia respostas.
- Gestor: acompanha consultas por area, topicos, avaliacoes e engajamento.
- Admin: gerencia documentos, usuarios, perfis, status da base e logs completos.

## Privacidade e nuvem

Esta versao nao envia dados para provedores externos. O modo local usa `data/` para testes e demonstracao, enquanto a configuracao de producao exige `SESSION_SECRET` forte, HTTPS ou proxy seguro, e permite apontar documentos para um repositorio interno por `DOCUMENT_REPOSITORY_PATH`.

As variaveis de ambiente estao documentadas em `.env.example`. Orientacoes de producao estao em `docs/producao.md`.

## Testes

```bash
npm test
```

O teste sobe o servidor em uma porta isolada, autentica, consulta o chat, registra avaliacao e valida rotas de gestor e admin.
