# Configuracao Para Producao

## Requisitos antes de producao

- Configurar `NODE_ENV=production`.
- Definir `SESSION_SECRET` com uma chave forte e exclusiva.
- Habilitar `HTTPS_ENABLED=true` com certificado e chave, ou `TRUST_PROXY=true` quando houver proxy corporativo com HTTPS.
- Manter `ALLOW_JSON_STORAGE_IN_PRODUCTION=false` ate conectar um banco corporativo privado.
- Configurar SSO corporativo por proxy autenticado quando disponivel.
- Definir `DOCUMENT_REPOSITORY_PATH` apontando para um volume ou repositorio interno com controle de acesso.

## SSO Corporativo

O pacote suporta SSO por cabecalho confiavel, comum quando um proxy corporativo autentica o usuario antes da aplicacao.

Variaveis:

```text
SSO_ENABLED=true
SSO_MODE=trusted-header
SSO_EMAIL_HEADER=x-authenticated-email
LOCAL_LOGIN_ENABLED=false
TRUST_PROXY=true
```

O proxy deve enviar o e-mail corporativo ja validado no cabecalho definido em `SSO_EMAIL_HEADER`.

## Banco Corporativo

O armazenamento atual continua em JSON para desenvolvimento local. Em producao, o sistema bloqueia o uso desse armazenamento por padrao quando `NODE_ENV=production`.

Para ligar um banco corporativo, substitua as funcoes `readJson` e `writeJson` por um adaptador interno com as mesmas entidades:

- `users`
- `documents`
- `logs`

O restante do codigo ja concentra os acessos nesses pontos, facilitando a troca sem alterar as telas.

## Documentos

Quando `DOCUMENT_REPOSITORY_PATH` estiver definido, o conteudo dos novos documentos passa a ser gravado no caminho informado, e o cadastro guarda apenas a referencia do arquivo. Use um caminho em volume privado, com backup e controle de acesso corporativo.
